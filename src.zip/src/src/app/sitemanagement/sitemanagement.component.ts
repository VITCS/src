import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sitemanagement',
  templateUrl: './sitemanagement.component.html',
  styleUrls: ['./sitemanagement.component.css']
})
export class SitemanagementComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
