import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SitemanagementComponent } from './sitemanagement.component';

describe('SitemanagementComponent', () => {
  let component: SitemanagementComponent;
  let fixture: ComponentFixture<SitemanagementComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SitemanagementComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SitemanagementComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
