export interface Employee {
    empID: number;
    firstName: string;
    lastName: string;
    email: string;
    attendance: number;
    leaves: number;
    percentage: number;
}
